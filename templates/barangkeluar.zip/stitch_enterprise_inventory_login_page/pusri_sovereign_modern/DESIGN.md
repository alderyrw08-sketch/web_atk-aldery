---
name: Pusri Sovereign Modern
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4850'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7881'
  outline-variant: '#bec8d2'
  surface-tint: '#006591'
  primary: '#006591'
  on-primary: '#ffffff'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#89ceff'
  secondary: '#00668a'
  on-secondary: '#ffffff'
  secondary-container: '#40c2fd'
  on-secondary-container: '#004d6a'
  tertiary: '#006e2f'
  on-tertiary: '#ffffff'
  tertiary-container: '#00b351'
  on-tertiary-container: '#003c16'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses the institutional authority, agricultural vitality, and high-technology enterprise leadership of Indonesia's pioneer fertilizer and chemical corporation. The visual personality communicates precision engineering, state stewardship, and forward-looking ecological responsibility.

The design movement merges **Corporate Modernism** with an ultra-premium industrial clean room sensibility. The interface balances high-contrast official typography with crystal-clear chromatic surfaces, deep structural framing, and deliberate accents of agricultural emerald green and sovereign gold. Layouts avoid clutter, prioritizing institutional lucidity, structural integrity, and executive clarity.

## Colors

The palette establishes an official, sovereign, and clean state-enterprise atmosphere:

- **Primary (`#0EA5E9` - Deeper Sky Blue):** Directs executive actions, primary navigation bars, active indicators, and high-impact structural focal points.
- **Secondary (`#38BDF8` - Light Sky Blue):** Acts as communicative emphasis, active status rings, chart metrics, and interactive hover highlights.
- **Tertiary (`#22C55E` - Agricultural Emerald Green):** Designated strictly for growth, sustainability indicators, positive yield statistics, certification badges, and successful validation points.
- **Accent Line / Sovereign Detail (`#E5B93C` - Refined Gold):** Applied exclusively for fine borders, official state accreditation emblems, executive dividers, and distinction badges.
- **Surface & Backgrounds:**
  - Base Canvas: `#FFFFFF` (Pure White) and `#F8FAFC` (Slate Tint 50).
  - Surface Neutral Container: `#F0F9FF` (Subtle Sky Tint) and `#E0F2FE` (Ice Blue) for cards, data panels, and structural grouping.
- **Typography & Neutral Framework:**
  - Text Primary: `#0F172A` (Deep Slate / 900) ensuring crisp contrast.
  - Text Secondary: `#475569` (Muted Slate / 600).
  - Border Muted: `#E2E8F0` (Crisp Slate Line / 200).

## Typography

The typographic hierarchy relies entirely on **Plus Jakarta Sans**, utilizing its geometric clarity, tall x-height, and precise humanistic nuances. 

- **Titles & Display Headings:** Set with tight tracking (`-0.02em` to `-0.01em`) and bold weights to project executive certitude and governance rigor.
- **Body Text:** Uses balanced line heights (`1.5` to `1.6`) to maintain effortless legibility across extensive corporate reports, operational metrics, and logistics manifests.
- **Labels & Micro-data:** Utilize medium and semi-bold weights with slight positive tracking (`+0.01em` to `+0.05em`) for quick identification in data tables and status monitors.

## Layout & Spacing

The structural layout uses a disciplined 12-column fluid grid system anchored by clean margins and proportional rhythm:

- **Desktop (1280px+):** 12 columns with 24px (`1.5rem`) gutters and generous 40px (`2.5rem`) outer canvas margins. Dashboards and executive summaries are grouped into standard spans of 3, 4, 6, 8, or 12 columns.
- **Tablet (768px – 1023px):** 8 columns with 20px gutters and 24px margins. Dual-card analytical views collapse gracefully into side-by-side modules.
- **Mobile (< 768px):** 4 columns with 16px (`1rem`) gutters and 20px (`1.25rem`) side padding. Stacked single-column layouts prioritize primary KPIs and operational workflows.

Spacing values strictly adhere to an 8-point proportional scale, providing breathing room between institutional modules while keeping actionable data compact and accessible.

## Elevation & Depth

Visual hierarchy combines architectural surface stepping with crisp, highly focused shadows tinted slightly with cold navy slate:

- **Surface Levels:**
  - Base Canvas (`#FFFFFF` or `#F8FAFC`): The architectural foundation.
  - Surface Level 1 (`#FFFFFF` with 1px border `#E2E8F0` or `#E0F2FE`): Standard data modules, panels, and tables.
  - Surface Level 2 (Elevated): Cards, tooltips, and floating control bars.
- **Crisp Shadow Architecture:**
  - *Elevation Low (Resting Cards, Operational Containers):* `0 2px 4px -1px rgba(15, 23, 42, 0.04), 0 4px 6px -1px rgba(15, 23, 42, 0.06)`.
  - *Elevation Medium (Hover Cards, Dropdown Panels):* `0 8px 16px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.04)`.
  - *Elevation High (Modal Dialogs, Executive Drawers):* `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 10px 10px -5px rgba(15, 23, 42, 0.04)`.
- **Gold Accent Linework:** Premium enterprise dividers and distinction boundaries incorporate subtle 1px strokes of `#E5B93C` against ice blue or pure white backgrounds.

## Shapes

The geometric identity balances industrial solidity with soft, welcoming pill-shaped curvature. 

- **Primary Cards and Major Containers:** Standardized at 20px to 24px radius (`rounded-lg` through `rounded-xl`), creating large, smooth silhouettes that offset dense corporate data.
- **Interactive Controls (Buttons, Form Inputs, Status Chips):** Fully pill-shaped (`rounded-full` or 1rem to 2rem radius), creating inviting touch targets and visual harmony with the geometric geometry of Plus Jakarta Sans.
- **Internal Nested Elements:** Nested inner tiles scale down proportionally to 12px or 16px to prevent optical corner collisions.

## Components

- **Buttons:**
  - *Primary Button:* Solid `#0EA5E9` background, white label, full-pill radius (`9999px`), crisp low shadow, padding `12px 24px`. Hover shifts to `#0284C7` with medium elevation.
  - *Secondary Button:* Crisp border of 1.5px `#0EA5E9`, `#E0F2FE` tint background on hover, `#0EA5E9` label text.
  - *Accent Action:* Emerald green `#22C55E` for confirmation and dispatch operations.
- **Cards & Data Modules:**
  - Built with a pure white `#FFFFFF` surface, 20px or 24px rounded corners, and a perimeter stroke of 1px `#E0F2FE` (ice blue).
  - Executive header cards feature a delicate 1px `#E5B93C` gold accent top line or subtle emblem delimiter.
- **Input Fields:**
  - Height: 48px. Border: 1.5px `#E2E8F0`. Corner radius: 12px to 16px. Background: `#FFFFFF`.
  - Active/Focused: Border `#0EA5E9` with a subtle 3px glow ring in `rgba(56, 189, 248, 0.25)`.
- **Chips & Status Tags:**
  - Height: 28px. Fully pill-shaped.
  - Active/Success: `#22C55E` background tint (10%), solid `#16A34A` text, 1px border `rgba(34, 197, 94, 0.3)`.
  - Operational/Info: `#E0F2FE` background, `#0284C7` text, 1px border `#38BDF8`.
  - Sovereign/Special: `#FEF9C3` background, `#854D0E` text, 1px border `#E5B93C`.
- **Lists & Data Tables:**
  - Alternating rows using `#FFFFFF` and `#F8FAFC`. Header rows styled in uppercase micro-labels with a 1px solid bottom border in `#E2E8F0`.
- **Checkboxes & Radios:**
  - Checkboxes use 6px rounded squares; radios are full circles. Unchecked: 1.5px border `#94A3B8`. Checked: solid `#0EA5E9` fill with a crisp white checkmark or center pip.